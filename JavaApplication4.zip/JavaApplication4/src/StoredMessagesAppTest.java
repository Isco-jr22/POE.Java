import static org.junit.Assert.*;
import org.junit.Test;
import java.util.ArrayList;

public class StoredMessagesAppTest {

    @Test
    public void testLongestMessage() {

        ArrayList<String> messages = new ArrayList<>();

        messages.add("Did you get the cake?");
        messages.add("Where are you? You are late! I have asked you to be on time.");
        messages.add("Yohoooo, I am at your gate.");

        String longest = "";

        for (String msg : messages) {
            if (msg.length() > longest.length()) {
                longest = msg;
            }
        }

        assertEquals(
            "Where are you? You are late! I have asked you to be on time.",
            longest
        );
    }

    @Test
    public void testSearchMessageID() {

        ArrayList<String> messageIDs = new ArrayList<>();

        messageIDs.add("MSG001");
        messageIDs.add("MSG002");
        messageIDs.add("MSG003");

        boolean found = messageIDs.contains("MSG002");

        assertTrue(found);
    }

    @Test
    public void testSearchRecipient() {

        ArrayList<String> recipients = new ArrayList<>();

        recipients.add("+27834557896");
        recipients.add("+27838884567");
        recipients.add("+27834484567");

        boolean found = recipients.contains("+27838884567");

        assertTrue(found);
    }

    @Test
    public void testDeleteMessageHash() {

        ArrayList<String> hashes = new ArrayList<>();

        hashes.add("HASH001");
        hashes.add("HASH002");
        hashes.add("HASH003");

        hashes.remove("HASH002");

        assertFalse(hashes.contains("HASH002"));
    }

    @Test
    public void testSentMessagesArray() {

        ArrayList<String> sentMessages = new ArrayList<>();

        sentMessages.add("Did you get the cake?");

        assertEquals(1, sentMessages.size());
    }

    @Test
    public void testDisregardedMessagesArray() {

        ArrayList<String> disregardedMessages = new ArrayList<>();

        disregardedMessages.add("Yohoooo, I am at your gate.");

        assertEquals(1, disregardedMessages.size());
    }
}