import static org.junit.Assert.*;
import java.util.ArrayList;
import org.junit.Test;

public class StoredMessagesAppTest {

    @Test
    public void testSentMessagesArrayCorrectlyPopulated() {

        ArrayList<String> sentMessages = new ArrayList<>();

        sentMessages.add("Did you get the cake?");
        sentMessages.add("It is dinner time!");

        String expected =
                "Did you get the cake?, It is dinner time!";

        String actual =
                sentMessages.get(0) + ", " + sentMessages.get(1);

        assertEquals(expected, actual);
    }

    @Test
    public void testDisplayLongestMessage() {

        ArrayList<String> messages = new ArrayList<>();

        messages.add("Did you get the cake?");
        messages.add("Where are you? You are late! I have asked you to be on time.");
        messages.add("Yohoooo, I am at your gate.");
        messages.add("It is dinner time!");

        String longest = "";

        for (String message : messages) {

            if (message.length() > longest.length()) {
                longest = message;
            }
        }

        String expected =
                "Where are you? You are late! I have asked you to be on time.";

        assertEquals(expected, longest);
    }

    @Test
    public void testSearchMessageID() {

        String recipient = "0838884567";
        String message = "It is dinner time!";

        String expected = "It is dinner time!";

        assertEquals(expected, message);
    }
   
    @Test
    public void testSearchMessagesByRecipient() {

        String recipient = "+27838884567";

        ArrayList<String> messages = new ArrayList<>();

        messages.add("Where are you? You are late! I have asked you to be on time.");
        messages.add("Ok, I am leaving without you.");

        String expected =
                "Where are you? You are late! I have asked you to be on time., Ok, I am leaving without you.";

        String actual =
                messages.get(0) + ", " + messages.get(1);

        assertEquals(expected, actual);
    }
}