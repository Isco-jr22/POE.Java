import java.util.ArrayList;
import java.util.Scanner;

public class StoredMessagesApp {

    static ArrayList<String> sentMessages = new ArrayList<>();
    static ArrayList<String> disregardedMessages = new ArrayList<>();
    static ArrayList<String> storedMessages = new ArrayList<>();
    static ArrayList<String> messageHashes = new ArrayList<>();
    static ArrayList<String> messageIDs = new ArrayList<>();
    static ArrayList<String> senders = new ArrayList<>();
    static ArrayList<String> recipients = new ArrayList<>();

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        // Sample data (replace with JSON data if required)
        addStoredMessage("1001", "HASH001", "John", "Mary",
                "Hello Mary, how are you?");
        addStoredMessage("1002", "HASH002", "Tom", "Sarah",
                "Meeting starts at 2PM tomorrow.");
        addStoredMessage("1003", "HASH003", "John", "Sarah",
                "Please send me the project documents when available.");

        int choice;

        do {
            System.out.println("\n===== STORED MESSAGES MENU =====");
            System.out.println("1. Display sender and recipient");
            System.out.println("2. Display longest message");
            System.out.println("3. Search by Message ID");
            System.out.println("4. Search by Recipient");
            System.out.println("5. Delete by Hash");
            System.out.println("6. Display Full Report");
            System.out.println("0. Exit");

            System.out.print("Choose option: ");
            choice = input.nextInt();
            input.nextLine();

            switch (choice) {

                case 1:
                    displaySendersAndRecipients();
                    break;

                case 2:
                    displayLongestMessage();
                    break;

                case 3:
                    System.out.print("Enter Message ID: ");
                    String id = input.nextLine();
                    searchMessageID(id);
                    break;

                case 4:
                    System.out.print("Enter Recipient: ");
                    String recipient = input.nextLine();
                    searchRecipient(recipient);
                    break;

                case 5:
                    System.out.print("Enter Message Hash: ");
                    String hash = input.nextLine();
                    deleteMessage(hash);
                    break;

                case 6:
                    displayReport();
                    break;

                case 0:
                    System.out.println("Program Closed.");
                    break;

                default:
                    System.out.println("Invalid option.");
            }

        } while (choice != 0);

        input.close();
    }

    public static void addStoredMessage(String id, String hash,
                                        String sender,
                                        String recipient,
                                        String message) {

        messageIDs.add(id);
        messageHashes.add(hash);
        senders.add(sender);
        recipients.add(recipient);
        storedMessages.add(message);
    }

    // (a)
    public static void displaySendersAndRecipients() {

        System.out.println("\nSENDERS AND RECIPIENTS");

        for (int i = 0; i < storedMessages.size(); i++) {
            System.out.println("Sender: " + senders.get(i)
                    + " | Recipient: " + recipients.get(i));
        }
    }

    // (b)
    public static void displayLongestMessage() {

        String longest = "";

        for (String msg : storedMessages) {
            if (msg.length() > longest.length()) {
                longest = msg;
            }
        }

        System.out.println("\nLongest Message:");
        System.out.println(longest);
    }

    // (c)
    public static void searchMessageID(String id) {

        for (int i = 0; i < messageIDs.size(); i++) {

            if (messageIDs.get(i).equals(id)) {

                System.out.println("Recipient: "
                        + recipients.get(i));

                System.out.println("Message: "
                        + storedMessages.get(i));
                return;
            }
        }

        System.out.println("Message ID not found.");
    }

    // (d)
    public static void searchRecipient(String recipient) {

        boolean found = false;

        for (int i = 0; i < recipients.size(); i++) {

            if (recipients.get(i)
                    .equalsIgnoreCase(recipient)) {

                System.out.println("\nMessage ID: "
                        + messageIDs.get(i));

                System.out.println("Message: "
                        + storedMessages.get(i));

                found = true;
            }
        }

        if (!found) {
            System.out.println("No messages found.");
        }
    }

    // (e)
    public static void deleteMessage(String hash) {

        for (int i = 0; i < messageHashes.size(); i++) {

            if (messageHashes.get(i).equals(hash)) {

                messageHashes.remove(i);
                messageIDs.remove(i);
                senders.remove(i);
                recipients.remove(i);
                storedMessages.remove(i);

                System.out.println("Message deleted.");
                return;
            }
        }

        System.out.println("Hash not found.");
    }

    // (f)
    public static void displayReport() {

        System.out.println("\nFULL MESSAGE REPORT");

        for (int i = 0; i < storedMessages.size(); i++) {

            System.out.println("----------------------------");
            System.out.println("Message ID : " + messageIDs.get(i));
            System.out.println("Hash       : " + messageHashes.get(i));
            System.out.println("Sender     : " + senders.get(i));
            System.out.println("Recipient  : " + recipients.get(i));
            System.out.println("Message    : " + storedMessages.get(i));
        }
    }
}